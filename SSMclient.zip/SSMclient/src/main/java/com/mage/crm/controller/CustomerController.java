package com.mage.crm.controller;

import com.mage.crm.base.BaseController;
import com.mage.crm.service.CustomerService;
import com.mage.crm.service.UserService;
import com.mage.crm.vo.Customer;
import com.mage.crm.vo.User;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import javax.annotation.Resource;
import java.util.List;

@Controller
@RequestMapping("customer")
public class CustomerController extends BaseController {
    @Resource
    public CustomerService customerService;
    @ResponseBody
    @RequestMapping("queryAllCustomers")
    public List<Customer> queryAllCustomers(){
        List<Customer> customers = customerService.queryAllCustomers();
        return customerService.queryAllCustomers();
    }
}

