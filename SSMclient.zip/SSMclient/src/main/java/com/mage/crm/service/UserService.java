package com.mage.crm.service;

import com.github.pagehelper.StringUtil;
import com.mage.crm.dao.UserDao;
import com.mage.crm.model.UserModel;
import com.mage.crm.util.AssertUtil;
import com.mage.crm.util.Base64Util;
import com.mage.crm.util.Md5Util;
import com.mage.crm.vo.SaleChance;
import com.mage.crm.vo.User;
import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;
import java.util.Date;
import java.util.List;

@Service
public class UserService {

    @Resource
    private UserDao userDao;

    public UserModel userLogin(String userName , String userPwd){
        User user = userDao.queryUserByName(userName);
        AssertUtil.isTrue(null==user,"用户不存在");
        AssertUtil.isTrue("0".equals(user.getIsValid()),"该用户已经失效");
        //userPwd=Md5Util.encode(userPwd);//对传过来的密码进行Md5加密,然后再与数据库中的密码进行比较
        AssertUtil.isTrue(!userPwd.equals(user.getUserPwd()),"密码错误");
        return createUserModel(user);
    }

    public UserModel createUserModel(User user){
        UserModel userModel = new UserModel();
        userModel.setTrueName(user.getTrueName());
        userModel.setUserName(user.getUserName());
        String userId = Base64Util.encode(user.getId());//加密之后的userId
        userModel.setUserId(userId);
        return userModel;
    }

    public void updatePwd(String userId,String oldPassword,String newPasswrord,String confirmPassword){
        AssertUtil.isTrue(null==userId,"非法用户");
        AssertUtil.isTrue("".equals(newPasswrord)||null==newPasswrord,"新密码不能为空");
        AssertUtil.isTrue(!newPasswrord.equals(confirmPassword),"新密码与确定密码不一致");
        User user = userDao.queryUserById(userId);
        AssertUtil.isTrue(null==user,"用户已经不存在");
        AssertUtil.isTrue(!oldPassword.equals(user.getUserPwd()),"原始密码输入错误");
        Integer integer=userDao.updatePwd(userId,newPasswrord);
        AssertUtil.isTrue(integer<1,"更新密码失败");
    }



    public List<User> queryAllCustomerManager(){
        List<User> userList = userDao.queryAllCustomerManager();
        return userList;
    }
}
