package com.mage.crm.query;

import com.mage.crm.base.BaseQuery;

public class CusDevPlanQuery extends BaseQuery {
    public Integer saleChanceId;
    public Integer getSaleChanceId() {
        return saleChanceId;
    }
    public void setSaleChanceId(Integer saleChanceId) {
        this.saleChanceId = saleChanceId;
    }

}
