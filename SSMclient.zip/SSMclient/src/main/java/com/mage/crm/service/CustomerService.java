package com.mage.crm.service;

import com.mage.crm.dao.CustomerDao;
import com.mage.crm.vo.Customer;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;
import java.util.List;

@Service
public class CustomerService {
    @Resource
    private CustomerDao customerDao;

    public List<Customer> queryAllCustomers(){
        List<Customer> customerList = customerDao.queryAllCustomers();
        return customerDao.queryAllCustomers();
    }

}
